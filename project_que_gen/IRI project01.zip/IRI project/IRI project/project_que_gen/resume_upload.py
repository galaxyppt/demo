# question_generation.py
import pdfplumber
import re
from sklearn.feature_extraction.text import TfidfVectorizer
import random
import spacy

# Load spaCy model for NLP processing (for keyword extraction from user response)
nlp = spacy.load("en_core_web_sm")

class ResumeQuestionGenerator:
    def __init__(self, pdf_path):
        self.pdf_path = pdf_path
        self.questions = []
        self.current_index = 0
        self._load_questions()

    def _extract_text_from_pdf(self):
        with pdfplumber.open(self.pdf_path) as pdf:
            text = ""
            for page in pdf.pages:
                page_text = page.extract_text()
                if page_text:
                    text += page_text
        return text

    def _split_resume_into_sections(self, resume_text):
        sections = {
            "Experience": "",
            "Education": "",
            "Skills": "",
            "Certifications": ""
        }

        experience_pattern = r"(experience|work/s*history|employment/s*history).*?(?=(education|skills|certifications|$))"
        education_pattern = r"(education|academic/s*background).*?(?=(experience|skills|certifications|$))"
        skills_pattern = r"(skills|technical/s*skills).*?(?=(experience|education|certifications|$))"
        certifications_pattern = r"(certifications|courses).*?(?=(experience|education|skills|$))"

        sections["Experience"] = re.search(experience_pattern, resume_text, re.DOTALL | re.IGNORECASE)
        sections["Education"] = re.search(education_pattern, resume_text, re.DOTALL | re.IGNORECASE)
        sections["Skills"] = re.search(skills_pattern, resume_text, re.DOTALL | re.IGNORECASE)
        sections["Certifications"] = re.search(certifications_pattern, resume_text, re.DOTALL | re.IGNORECASE)

        for section, content in sections.items():
            if content:
                sections[section] = content.group(0).strip()
            else:
                sections[section] = ""

        return sections

    def _extract_keywords_from_text(self, text):
        vectorizer = TfidfVectorizer(stop_words="english")
        tfidf_matrix = vectorizer.fit_transform([text])
        feature_names = vectorizer.get_feature_names_out()
        tfidf_scores = tfidf_matrix.sum(axis=0).A1
        sorted_indices = tfidf_scores.argsort()[::-1]
        top_keywords = [feature_names[i] for i in sorted_indices[:10]]
        return top_keywords

    def _generate_questions_from_keywords(self, section, keywords, context_keywords=None):
        questions = []
        if context_keywords:
            for keyword in context_keywords:
                if section == "Experience":
                    question = f"Can you describe how your experience with {keyword} is relevant to the position?"
                elif section == "Skills":
                    question = f"Can you explain how you used {keyword} in your previous work?"
                questions.append(question)

        if not questions:
            for keyword in keywords:
                if section == "Experience":
                    question = f"Can you describe a project where you used {keyword}?"
                    questions.append(question)
                elif section == "Skills":
                    question = f"How proficient are you in {keyword}?"
                    questions.append(question)

        return questions

    def _load_questions(self):
        resume_text = self._extract_text_from_pdf()
        sections = self._split_resume_into_sections(resume_text)

        for section, text in sections.items():
            if text and section in ["Skills", "Experience"]:
                keywords = self._extract_keywords_from_text(text)
                questions = self._generate_questions_from_keywords(section, keywords)
                self.questions.extend(questions)

    def get_next_question(self, context_keywords=None):
        if self.current_index < len(self.questions):
            question = self.questions[self.current_index]
            self.current_index += 1
            return question
        else:
            return None

    def extract_keywords_from_response(self, response_text):
        doc = nlp(response_text)
        keywords = [token.text for token in doc if not token.is_stop and not token.is_punct]
        return keywords
